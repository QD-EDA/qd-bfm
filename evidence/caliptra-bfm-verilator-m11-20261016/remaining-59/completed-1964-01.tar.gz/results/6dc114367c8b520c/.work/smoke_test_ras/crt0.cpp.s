# 0 "/home/dsell/toolchains/iverilog-c339/firmware/caliptra-rtl/src/integration/test_suites/libs/riscv_hw_if/crt0.s"
# 0 "<built-in>"
# 0 "<command-line>"
# 1 "/home/dsell/toolchains/iverilog-c339/firmware/caliptra-rtl/src/integration/test_suites/libs/riscv_hw_if/crt0.s"
# SPDX-License-Identifier: Apache-2.0
# Copyright 2020 Western Digital Corporation or its affiliates.

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

# http:

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.



# 1 "/home/dsell/slurm-runs/caliptra-bfm/a2/m11-overlay-remaining-59-20261016-01/results/6dc114367c8b520c/.work/smoke_test_ras/caliptra_defines.h" 1
# 23 "/home/dsell/slurm-runs/caliptra-bfm/a2/m11-overlay-remaining-59-20261016-01/results/6dc114367c8b520c/.work/smoke_test_ras/caliptra_defines.h"
# 1 "/home/dsell/slurm-runs/caliptra-bfm/a2/m11-overlay-remaining-59-20261016-01/results/6dc114367c8b520c/.work/smoke_test_ras/defines.h" 1
# 24 "/home/dsell/slurm-runs/caliptra-bfm/a2/m11-overlay-remaining-59-20261016-01/results/6dc114367c8b520c/.work/smoke_test_ras/caliptra_defines.h" 2
# 1 "/home/dsell/slurm-runs/caliptra-bfm/a2/m11-overlay-remaining-59-20261016-01/results/6dc114367c8b520c/.work/smoke_test_ras/caliptra_reg.h" 1
# 25 "/home/dsell/slurm-runs/caliptra-bfm/a2/m11-overlay-remaining-59-20261016-01/results/6dc114367c8b520c/.work/smoke_test_ras/caliptra_defines.h" 2
# 19 "/home/dsell/toolchains/iverilog-c339/firmware/caliptra-rtl/src/integration/test_suites/libs/riscv_hw_if/crt0.s" 2

.set mfdc, 0x7f9
.set mrac, 0x7c0
.extern _data_lma_start, _data_lma_end
.extern _bss_lma_start, _bss_lma_end
.extern _data_vma_start, _bss_vma_start
.section .text.init
.global _start
_start:


    csrw minstret, zero
    csrw minstreth, zero
# 47 "/home/dsell/toolchains/iverilog-c339/firmware/caliptra-rtl/src/integration/test_suites/libs/riscv_hw_if/crt0.s"
    li t0, 0xAAAAA0A9
    csrw mrac, t0

    li t0, 4
    fence.i
    csrw mfdc, t0
    fence.i



    la t0, early_trap_vector
    csrw mtvec, t0


    la t0, _data_lma_start
    la t1, _data_lma_end
    la t2, _data_vma_start
    bgeu t0, t1, bss_cp_setup
data_cp_loop:
    lw t3, 0(t0)
    sw t3, 0(t2)
    addi t0, t0, 4
    addi t2, t2, 4
    bltu t0, t1, data_cp_loop

bss_cp_setup:

    la t0, _bss_lma_start
    la t1, _bss_lma_end
    la t2, _bss_vma_start
    bgeu t0, t1, post_cp_loops
bss_cp_loop:
    lw t3, 0(t0)
    sw t3, 0(t2)
    addi t0, t0, 4
    addi t2, t2, 4
    bltu t0, t1, bss_cp_loop

post_cp_loops:

    la sp, STACK

    call main


.global _finish

_finish:
    li t0, (0x300300cc)
    addi t5, zero, 0xff
    sw t5, 0(t0)
    beq zero, zero, _finish
.rept 100
    nop
.endr


.data
trap_msg:
.ascii "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n"
.ascii "   TRAP VECTOR EXECUTING! KILL SIM!!!   \n"
.ascii "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx\n"
.byte 0






.section .text.metal.init.trapvec
.align 2
.global early_trap_vector
early_trap_vector:
.cfi_startproc
csrr t0, mcause
csrr t1, mepc
csrr t2, mtval
li t3, (0x300300cc)
la t4, trap_msg
trap_print_loop:
   lb t0, 0(t4)
   sw t0, 0(t3)
   addi t4, t4, 1
   bnez t0, trap_print_loop
addi t5, zero, 0x1
sw t5, 0(t3)
j early_trap_vector
.cfi_endproc
