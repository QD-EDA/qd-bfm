["/usr/bin/make", "-C", "/home/dsell/slurm-runs/caliptra-bfm/a2/m19-row93-ahb-filelist-gate-20261019-01/tasks/row-93/output/native-models/dilithium-ref", "CC=/usr/bin/cc", "test/test_dilithium5"]
