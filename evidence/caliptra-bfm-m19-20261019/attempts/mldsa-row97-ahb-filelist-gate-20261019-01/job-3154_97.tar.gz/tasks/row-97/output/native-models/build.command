["/usr/bin/make", "-C", "/home/dsell/slurm-runs/caliptra-bfm/a2/m19-row97-ahb-filelist-gate-20261019-02/tasks/row-97/output/native-models/dilithium-ref", "CC=/usr/bin/cc", "test/test_dilithium5"]
