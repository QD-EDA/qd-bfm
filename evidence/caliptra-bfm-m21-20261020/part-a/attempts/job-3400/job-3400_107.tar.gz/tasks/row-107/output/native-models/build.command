["/usr/bin/make", "-C", "/home/dsell/slurm-runs/caliptra-bfm/a2/m21-a2-raw-interface-20261020-01/tasks/row-107/output/native-models/dilithium-ref", "CC=/usr/bin/cc", "test/test_dilithium5"]
