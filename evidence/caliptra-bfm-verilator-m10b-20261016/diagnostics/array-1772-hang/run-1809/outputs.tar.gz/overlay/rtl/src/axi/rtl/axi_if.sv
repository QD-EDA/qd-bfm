// SPDX-License-Identifier: Apache-2.0
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
// http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
//
// Description:
//      Signals for a standard AXI4 compliant interface
//

interface axi_if #(parameter integer AW = 32, parameter integer DW = 32, parameter integer IW = 8, parameter integer UW = 32) (input logic clk, input logic rst_n);

    import axi_pkg::*;

    // AXI AR
    logic [AW-1:0]                 araddr;
    logic [$bits(axi_burst_e)-1:0] arburst;
    logic [2:0]                    arsize;
    logic [7:0]                    arlen;
    logic [UW-1:0]                 aruser;
    logic [IW-1:0]                 arid;
    logic                          arlock;
    logic                          arvalid;
    logic                          arready;

    // AXI R
    logic [DW-1:0]                 rdata;
    logic [$bits(axi_resp_e)-1:0]  rresp;
    logic [IW-1:0]                 rid;
    logic [UW-1:0]                 ruser;
    logic                          rlast;
    logic                          rvalid;
    logic                          rready;

    // AXI AW
    logic [AW-1:0]                 awaddr;
    logic [$bits(axi_burst_e)-1:0] awburst;
    logic [2:0]                    awsize;
    logic [7:0]                    awlen;
    logic [UW-1:0]                 awuser;
    logic [IW-1:0]                 awid;
    logic                          awlock;
    logic                          awvalid;
    logic                          awready;

    // AXI W
    logic [DW-1:0]                 wdata;
    logic [DW/8-1:0]               wstrb;
    logic [UW-1:0]                 wuser;
    logic                          wvalid;
    logic                          wready;
    logic                          wlast;

    // AXI B
    logic [$bits(axi_resp_e)-1:0]  bresp;
    logic [IW-1:0]                 bid;
    logic [UW-1:0]                 buser;
    logic                          bvalid;
    logic                          bready;

    // Modport for read manager
    modport r_mgr (
        // AR
        output araddr,
        output arburst,
        output arsize,
        output arlen,
        output aruser,
        output arid,
        output arlock,
        output arvalid,
        input  arready,
        // R
        input  rdata,
        input  rresp,
        input  rid,
        input  ruser,
        input  rlast,
        input  rvalid,
        output rready
    );

    // Modport for write manager
    modport w_mgr (
        // AW
        output awaddr,
        output awburst,
        output awsize,
        output awlen,
        output awuser,
        output awid,
        output awlock,
        output awvalid,
        input  awready,
        // W
        output wdata,
        output wstrb,
        output wuser,
        output wvalid,
        input  wready,
        output wlast,
        // B
        input  bresp,
        input  bid,
        input  buser,
        input  bvalid,
        output bready
    );

    // Modport for read subordinate
    modport r_sub (
        // AR
        input  araddr,
        input  arburst,
        input  arsize,
        input  arlen,
        input  aruser,
        input  arid,
        input  arlock,
        input  arvalid,
        output arready,
        // R
        output rdata,
        output rresp,
        output rid,
        output ruser,
        output rlast,
        output rvalid,
        input  rready
    );

    // Modport for write subordinate
    modport w_sub (
        // AW
        input  awaddr,
        input  awburst,
        input  awsize,
        input  awlen,
        input  awuser,
        input  awid,
        input  awlock,
        input  awvalid,
        output awready,
        // W
        input  wdata,
        input  wstrb,
        input  wuser,
        input  wvalid,
        output wready,
        input  wlast,
        // B
        output bresp,
        output bid,
        output buser,
        output bvalid,
        input  bready
    );

    // synopsys translate_off

    `ifdef VERILATOR
    bit m10b_trace_active = 0;
    int unsigned m10b_trace_event = 0;
    int unsigned m10b_trace_sample = 0;
    clocking m10b_trace_cb @(posedge clk);
        input #1step awaddr, awvalid, awready;
        input #1step wdata, wstrb, wlast, wvalid, wready;
        input #1step bresp, bvalid, bready;
    endclocking
    always @(awaddr or awvalid or awready or wvalid or wready or bvalid or bready) begin
        if (!m10b_trace_active && rst_n && awvalid && (awaddr == AW'(32'h30030200))) begin
            m10b_trace_active = 1;
            m10b_trace_event = 0;
            m10b_trace_sample = 0;
            $display("M10B_AW_W_B_TRACE_START time=%0t realtime=%0.6f path=%m awaddr=%h", $time, $realtime, awaddr);
        end
        if (m10b_trace_active) begin
            $display("M10B_AW_W_B_TRACE_CHANGE time=%0t realtime=%0.6f event=%0d clk=%b AW=%b/%b/%h W=%b/%b/%h/%h/%b B=%b/%b/%b",
                $time, $realtime, m10b_trace_event, clk, awvalid, awready, awaddr,
                wvalid, wready, wdata, wstrb, wlast, bvalid, bready, bresp);
            m10b_trace_event = m10b_trace_event + 1;
            if (bvalid && bready) begin
                $display("M10B_AW_W_B_TRACE_DONE time=%0t realtime=%0.6f path=%m", $time, $realtime);
                m10b_trace_active = 0;
            end else if (m10b_trace_event >= 32) begin
                $display("M10B_AW_W_B_TRACE_WINDOW_END time=%0t realtime=%0.6f path=%m", $time, $realtime);
                m10b_trace_active = 0;
            end
        end
    end
    always @(m10b_trace_cb) begin
        if (m10b_trace_active) begin
            $display("M10B_AW_W_B_SAMPLE realtime=%0.6f sample=%0d AW=%b/%b/%h W=%b/%b/%h/%h/%b B=%b/%b/%b",
                $realtime, m10b_trace_sample,
                m10b_trace_cb.awvalid, m10b_trace_cb.awready, m10b_trace_cb.awaddr,
                m10b_trace_cb.wvalid, m10b_trace_cb.wready, m10b_trace_cb.wdata,
                m10b_trace_cb.wstrb, m10b_trace_cb.wlast,
                m10b_trace_cb.bvalid, m10b_trace_cb.bready, m10b_trace_cb.bresp);
            m10b_trace_sample = m10b_trace_sample + 1;
        end
    end
    `endif

    // Tasks
    `ifdef VERILATOR
        `define EQ__ =
        // SVA samples before the edge; keep AW drives out of its sampling region.
        `define AW_EQ__ <=
        `define TIME_ALGN #100ps
        // Wait on the clock itself; Verilator's clocking-block event spun at the first write.
        `define WAIT_AWREADY @(posedge clk)
        `define SAMPLE_AWREADY axi_if_awready_cb.awready
        clocking axi_if_awready_cb @(posedge clk);
            input #1step awready;
        endclocking
        // Keep W valid/data stable through the assertion sample at the clock edge.
        `define W_EQ__ <=
        `define WAIT_WREADY @(posedge clk)
        `define SAMPLE_WREADY axi_if_wready_cb.wready
        clocking axi_if_wready_cb @(posedge clk);
            input #1step wready;
        endclocking
    `else
        `define EQ__ <=
        `define AW_EQ__ <=
        `define W_EQ__ <=
        `define TIME_ALGN
        `define WAIT_AWREADY @(posedge clk)
        `define SAMPLE_AWREADY awready
        `define WAIT_WREADY @(posedge clk)
        `define SAMPLE_WREADY wready
    `endif

    `ifndef SYNTHESIS
    `ifndef XCELIUM
        task rst_mgr();
            araddr  `EQ__ '0;
            arburst `EQ__ AXI_BURST_FIXED;
            arsize  `EQ__ '0;
            arlen   `EQ__ '0;
            aruser  `EQ__ '0;
            arid    `EQ__ '0;
            arlock  `EQ__ '0;
            arvalid `EQ__ '0;

            rready  `EQ__ '0;

            awaddr  `EQ__ '0;
            awburst `EQ__ AXI_BURST_FIXED;
            awsize  `EQ__ '0;
            awlen   `EQ__ '0;
            awuser  `EQ__ '0;
            awid    `EQ__ '0;
            awlock  `EQ__ '0;
            awvalid `EQ__ '0;

            wdata   `EQ__ '0;
            wstrb   `EQ__ '0;
            wuser   `EQ__ '0;
            wvalid  `EQ__ '0;
            wlast   `EQ__ '0;

            bready  `EQ__ '0;
        endtask

        // TODO: handle IDs?
        task get_read_beat(output logic [DW-1:0] data,
                        output logic [UW-1:0] user,
                        output axi_resp_e     resp);
            `TIME_ALGN
            rready `EQ__ 1;
            do
                @(posedge clk);
            while (!rvalid);
            data   `EQ__ rdata;
            user   `EQ__ ruser;
            resp   `EQ__ axi_resp_e'(rresp);
            `TIME_ALGN
            rready `EQ__ 0;
            wait(!rready);
        endtask

        // Read: default to single beat of native data width
        task axi_read(input  logic [AW-1:0] addr,
                    input  axi_burst_e    burst = AXI_BURST_INCR,
                    input  logic [2:0]    size  = $clog2(DW/8),
                    input  logic [7:0]    len   = 0,
                    input  logic [UW-1:0] user  = UW'(0),
                    input  logic [IW-1:0] id    = IW'(0),
                    input  logic          lock  = 1'b0,
                    output logic [DW-1:0] data [],
                    output logic [UW-1:0] resp_user [],
                    output axi_resp_e     resp []);
            axi_resp_e     beat_resp;
            logic [UW-1:0] beat_user;
            logic [DW-1:0] beat_data;
            while(!rst_n) @(posedge clk);
            do begin
                `TIME_ALGN
                araddr  `EQ__ addr;
                arburst `EQ__ burst;
                arsize  `EQ__ size;
                arlen   `EQ__ len;
                aruser  `EQ__ user;
                arid    `EQ__ id;
                arlock  `EQ__ lock;
                arvalid `EQ__ 1;
                @(posedge clk);
            end while(!arready);
            `TIME_ALGN
            araddr  `EQ__ '0;
            arburst `EQ__ AXI_BURST_FIXED;
            arsize  `EQ__ '0;
            arlen   `EQ__ '0;
            aruser  `EQ__ '0;
            arid    `EQ__ '0;
            arlock  `EQ__ '0;
            arvalid `EQ__ '0;
            data = new[len+1];
            resp = new[len+1];
            for (int beat=0; beat <= len; beat++) begin
                get_read_beat(beat_data, beat_user, beat_resp);
                data[beat]      = beat_data;
                resp_user[beat] = beat_user;
                resp[beat]      = beat_resp;
            end
        endtask

        task axi_read_single(input  logic [AW-1:0] addr,
                            input  logic [UW-1:0] user  = UW'(0),
                            input  logic [IW-1:0] id    = IW'(0),
                            input  logic          lock  = 1'b0,
                            output logic [DW-1:0] data,
                            output logic [UW-1:0] resp_user,
                            output axi_resp_e     resp);
            automatic axi_resp_e     burst_resp[];
            automatic logic [UW-1:0] burst_ruser[];
            automatic logic [DW-1:0] burst_data[];
            axi_read(.addr     (addr       ),
                    .user     (user       ),
                    .id       (id         ),
                    .lock     (lock       ),
                    .data     (burst_data ),
                    .resp_user(burst_ruser),
                    .resp     (burst_resp ));
            data      = burst_data[0];
            resp_user = burst_ruser[0];
            resp      = burst_resp[0];
        endtask

        task send_write_beat(input logic last,
                            input logic [DW-1:0] data,
                            input logic [UW-1:0] user,
                            input logic [DW/8-1:0] strb);
            `TIME_ALGN
            wvalid `W_EQ__ 1;
            wlast  `W_EQ__ last;
            wdata  `W_EQ__ data;
            wstrb  `W_EQ__ strb;
            wuser  `W_EQ__ user;
            do
                `WAIT_WREADY;
            while (!`SAMPLE_WREADY);
            `TIME_ALGN
            wvalid `W_EQ__ '0;
            wlast  `W_EQ__ '0;
            wdata  `W_EQ__ '0;
            wstrb  `W_EQ__ '0;
            wuser  `W_EQ__ '0;
            wait(!wvalid);
        endtask

        // TODO handle ID
        task get_write_resp(output axi_resp_e     resp,
                            output logic [UW-1:0] user);
            `TIME_ALGN
            bready `EQ__ 1;
            do
                @(posedge clk);
            while(!bvalid);
            resp `EQ__ axi_resp_e'(bresp);
            user `EQ__ buser;
            `TIME_ALGN
            bready `EQ__ 0;
            wait(!bready);
        endtask

        task axi_write(input  logic [AW-1:0]   addr,
                    input  axi_burst_e      burst = AXI_BURST_INCR,
                    input  logic [2:0]      size  = $clog2(DW/8),
                    input  logic [7:0]      len   = 0,
                    input  logic [UW-1:0]   user  = UW'(0),
                    input  logic [IW-1:0]   id    = IW'(0),
                    input  logic            lock  = 1'b0,
                    input  logic [DW-1:0]   data [],
                    input  logic            use_strb = 0,
                    input  logic [DW/8-1:0] strb [],
                    input  logic            use_write_user = 0,
                    input  logic [UW-1:0]   write_user [],
                    output axi_resp_e       resp,
                    output logic [UW-1:0]   resp_user);
            while(!rst_n) @(posedge clk);
            do begin
                `TIME_ALGN
                awaddr  `AW_EQ__ addr;
                awburst `AW_EQ__ burst;
                awsize  `AW_EQ__ size;
                awlen   `AW_EQ__ len;
                awuser  `AW_EQ__ user;
                awid    `AW_EQ__ id;
                awlock  `AW_EQ__ lock;
                awvalid `AW_EQ__ 1;
                `WAIT_AWREADY;
            end while(!`SAMPLE_AWREADY);
            `TIME_ALGN
            awaddr  `AW_EQ__ '0;
            awburst `AW_EQ__ AXI_BURST_FIXED;
            awsize  `AW_EQ__ '0;
            awlen   `AW_EQ__ '0;
            awuser  `AW_EQ__ '0;
            awid    `AW_EQ__ '0;
            awlock  `AW_EQ__ '0;
            awvalid `AW_EQ__ '0;
            fork
                for (int beat=0; beat <= len; beat++)
                    send_write_beat(beat == len, data[beat], use_write_user ? write_user[beat] : UW'(0), use_strb ? strb[beat] : {DW/8{1'b1}});
                get_write_resp(resp, resp_user);
            join
        endtask

        task axi_write_single(input  logic [AW-1:0] addr,
                            input  logic [UW-1:0] user  = UW'(0),
                            input  logic [IW-1:0] id    = IW'(0),
                            input  logic          lock  = 1'b0,
                            input  logic [DW-1:0] data,
                            input  logic [UW-1:0] write_user = UW'(0),
                            output axi_resp_e     resp,
                            output logic [UW-1:0] resp_user);
            automatic logic [DW/8-1:0] burst_strb[] = new[1]('{{DW/8{1'b1}}});
            automatic logic [UW  -1:0] burst_user[] = new[1]('{write_user});
            automatic logic [DW  -1:0] burst_data[] = new[1]('{data});
            axi_write(.addr(addr),
                    .user(user),
                    .id  (id  ),
                    .lock(lock),
                    .data(burst_data),
                    .use_strb(0),
                    .strb(burst_strb),
                    .use_write_user(0),
                    .write_user(burst_user),
                    .resp(resp),
                    .resp_user(resp_user));
        endtask
    `endif
    `endif

    `undef WAIT_AWREADY
    `undef SAMPLE_AWREADY
    `undef WAIT_WREADY
    `undef SAMPLE_WREADY
    `undef AW_EQ__
    `undef W_EQ__
    `undef EQ__
    `undef TIME_ALGN

    // synopsys translate_on

endinterface
